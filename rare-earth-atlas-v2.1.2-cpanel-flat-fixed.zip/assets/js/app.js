import { loadAppData, loadTranslations } from './data-service.js';
import { icon, getLocalized, pagePath, createSectionTitle, cardButton, revealAll, buildSourceLink, escapeHtml } from './ui.js';

const state = {
  lang: localStorage.getItem('atlas-language') || 'el',
  theme: localStorage.getItem('atlas-theme') || 'dark',
  data: null,
  galleryItems: [],
  lightboxIndex: 0,
  lightbox: { items: [], index: 0 }
};

function currentPage() {
  return document.body.dataset.page || 'home';
}

function t(key, options) {
  return window.i18next.t(key, options);
}

function themeLabel(theme) {
  return theme === 'dark' ? t('theme.dark') : t('theme.light');
}

function setTheme(theme) {
  state.theme = theme;
  document.documentElement.setAttribute('data-bs-theme', theme);
  localStorage.setItem('atlas-theme', theme);
  const toggle = document.querySelector('[data-action="theme-toggle"]');
  if (toggle) {
    toggle.innerHTML = `${theme === 'dark' ? icon('sun') : icon('moon')} ${escapeHtml(themeLabel(theme))}`;
  }
}

function setLanguage(lang) {
  state.lang = lang;
  localStorage.setItem('atlas-language', lang);
  window.i18next.changeLanguage(lang).then(() => render());
}

function getEntityById(collection = [], id) {
  return collection.find((item) => item.id === id);
}

function getMediaById(id) {
  return getEntityById(state.data?.media || [], id);
}

function resolveMedia(ref) {
  if (!ref) return null;
  if (typeof ref === 'string') return getMediaById(ref);
  return ref;
}

function mediaUrl(media) {
  if (!media?.src) return '';
  return media.src.startsWith('./') ? media.src : `./${media.src.replace(/^\.\//, '')}`;
}

function mediaImageAttrs(media, { containForIllustration = true } = {}) {
  const styles = [];
  const classes = [];
  if (media?.objectPosition) styles.push(`object-position:${media.objectPosition}`);
  if (media?.kind === 'illustration' && containForIllustration) classes.push('is-illustration');
  if (media?.renderMode === 'cover') classes.push('is-cover');
  return {
    className: classes.join(' '),
    styleAttr: styles.length ? ` style="${styles.join(';')}"` : ''
  };
}

function mediaLightboxButton(mediaId, label) {
  if (!mediaId) return '';
  return `<button class="media-zoom-btn" type="button" data-open="lightbox" data-media-id="${mediaId}" aria-label="${escapeHtml(label)}">${icon('camera')}</button>`;
}

function mediaPosition(media, variant = 'card') {
  return media?.focus?.[variant] || media?.focus?.card || '50% 50%';
}

function mediaFit(media, variant = 'card') {
  if (media?.kind === 'illustration') return 'contain';
  return media?.fit?.[variant] || media?.fit?.card || 'cover';
}

function mediaStyle(media, variant = 'card') {
  return `style="--media-pos:${mediaPosition(media, variant)}; --media-fit:${mediaFit(media, variant)};"`;
}

function entityImage(entity, fallbackPath) {
  const media = resolveMedia(entity?.mediaRef || entity?.coverMediaRef);
  if (media?.src) return mediaUrl(media);
  if (entity?.image) return entity.image.startsWith('./') ? entity.image : `./${entity.image.replace(/^\.\//, '')}`;
  return fallbackPath;
}

function mediaCredit(itemOrMedia) {
  const media = itemOrMedia?.src ? itemOrMedia : resolveMedia(itemOrMedia?.mediaRef || itemOrMedia?.coverMediaRef) || itemOrMedia;
  if (!media?.credit) return '';
  const bits = [media.credit.author, media.credit.license].filter(Boolean).map((part) => escapeHtml(part));
  if (!bits.length) return '';
  const sourceUrl = media.credit.sourceUrl ? escapeHtml(media.credit.sourceUrl) : '';
  const sourceOpen = sourceUrl ? `<a href="${sourceUrl}" target="_blank" rel="noreferrer">` : '';
  const sourceClose = sourceUrl ? '</a>' : '';
  return `<div class="credit-line small muted mt-3">${escapeHtml(t('cards.photoCredit'))}: ${sourceOpen}${bits.join(' · ')}${sourceClose}</div>`;
}

function localizedMedia(mediaRef) {
  const media = resolveMedia(mediaRef);
  return { media, localized: getLocalized(media, state.lang) };
}

function navLink(page, label) {
  const active = currentPage() === page ? 'active' : '';
  return `<a class="nav-link ${active}" href="${pagePath(page)}">${label}</a>`;
}

function buildMegaMenu() {
  const leadArticle = state.data?.articles?.[0];
  const secondArticle = state.data?.articles?.[1];
  return `
    <div class="mega-panel glass" id="discoverPanel" aria-hidden="true">
      <div class="mega-panel-grid">
        <section class="mega-column">
          <div class="section-kicker mb-3">${icon('layers')} ${escapeHtml(t('cards.quickLinks'))}</div>
          <h3>${escapeHtml(t('nav.discover'))}</h3>
          <p class="muted mb-4">${escapeHtml(t('cards.discoverLead'))}</p>
          <div class="mega-link-stack">
            <a class="mega-link" href="${pagePath('elements')}">
              <strong>${escapeHtml(t('nav.elements'))}</strong>
              <span>${escapeHtml(t('page.elementsLead'))}</span>
            </a>
            <a class="mega-link" href="${pagePath('applications')}">
              <strong>${escapeHtml(t('nav.applications'))}</strong>
              <span>${escapeHtml(t('page.applicationsLead'))}</span>
            </a>
            <a class="mega-link" href="${pagePath('gallery')}">
              <strong>${escapeHtml(t('nav.gallery'))}</strong>
              <span>${escapeHtml(t('page.galleryLead'))}</span>
            </a>
          </div>
        </section>

        <section class="mega-column">
          <div class="section-kicker mb-3">${icon('quote')} ${escapeHtml(t('cards.readingPaths'))}</div>
          <div class="mega-link-stack">
            ${leadArticle ? `
              <a class="mega-link" href="./article.html?id=${leadArticle.id}">
                <strong>${escapeHtml(leadArticle.translations?.[state.lang]?.title || leadArticle.translations?.el?.title)}</strong>
                <span>${escapeHtml(leadArticle.translations?.[state.lang]?.excerpt || leadArticle.translations?.el?.excerpt)}</span>
              </a>
            ` : ''}
            ${secondArticle ? `
              <a class="mega-link" href="./article.html?id=${secondArticle.id}">
                <strong>${escapeHtml(secondArticle.translations?.[state.lang]?.title || secondArticle.translations?.el?.title)}</strong>
                <span>${escapeHtml(secondArticle.translations?.[state.lang]?.excerpt || secondArticle.translations?.el?.excerpt)}</span>
              </a>
            ` : ''}
            <a class="mega-link" href="${pagePath('sources')}">
              <strong>${escapeHtml(t('nav.sources'))}</strong>
              <span>${escapeHtml(t('page.sourcesLead'))}</span>
            </a>
          </div>
        </section>

        <section class="mega-column mega-feature">
          <div class="section-kicker mb-3">${icon('camera')} ${escapeHtml(t('cards.featuredEssay'))}</div>
          ${leadArticle ? `
            <a class="mega-feature-card" href="./article.html?id=${leadArticle.id}">
              <div class="mega-feature-media" ${mediaStyle(resolveMedia(leadArticle.coverMediaRef), 'cover')}>
                <img src="${entityImage(leadArticle, './assets/img/gallery/atlas-overview.svg')}" alt="${escapeHtml(leadArticle.translations?.[state.lang]?.title || leadArticle.translations?.el?.title)}">
              </div>
              <div class="mega-feature-copy">
                <strong>${escapeHtml(leadArticle.translations?.[state.lang]?.title || leadArticle.translations?.el?.title)}</strong>
                <span>${escapeHtml(t('cards.openArticle'))}</span>
              </div>
            </a>
          ` : ''}
        </section>
      </div>
    </div>
  `;
}


function renderShell() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="ambient ambient-1"></div>
    <div class="ambient ambient-2"></div>
    <header class="container-tight site-header" id="siteHeader">
      <nav class="navbar navbar-expand-lg glass nav-shell" id="siteNav">
        <div class="container-fluid px-1">
          <a class="navbar-brand brand-badge" href="${pagePath('home')}">
            <span class="brand-mark"></span>
            <span>
              <span class="d-block">Rare Earth Atlas</span>
              <small class="text-body-secondary">${escapeHtml(t('site.subtitle'))}</small>
            </span>
          </a>
          <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#atlasNav" aria-label="${escapeHtml(t('nav.menu'))}">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="atlasNav">
            
<div class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
              ${navLink('home', t('nav.home'))}
              <div class="nav-item dropdown atlas-mega-wrap">
                <a class="nav-link dropdown-toggle ${['elements','applications','gallery','articles','sources','article'].includes(currentPage()) ? 'active' : ''}" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">${escapeHtml(t('nav.discover'))}</a>
                <div class="dropdown-menu atlas-mega-menu glass border-0 p-0 overflow-hidden">
                  <div class="atlas-mega-grid">
                    <div class="atlas-mega-intro">
                      <div class="section-kicker mb-3">${icon('spark')} ${escapeHtml(t('nav.discoverLead'))}</div>
                      <h3 class="h4 mb-2">Rare Earth Atlas</h3>
                      <p class="mb-0 muted">${escapeHtml(t('site.subtitle'))}</p>
                    </div>
                    <div class="atlas-mega-links">
                      <a class="atlas-mega-link" href="${pagePath('elements')}"><strong>${escapeHtml(t('nav.elements'))}</strong><span>${icon('atom')} 17 στοιχεία, χρήσεις και βασικά facts</span></a>
                      <a class="atlas-mega-link" href="${pagePath('applications')}"><strong>${escapeHtml(t('nav.applications'))}</strong><span>${icon('chip')} Συσκευές, οχήματα, ενέργεια και ιατρική</span></a>
                      <a class="atlas-mega-link" href="${pagePath('gallery')}"><strong>${escapeHtml(t('nav.gallery'))}</strong><span>${icon('camera')} Curated visuals με lightbox προβολή</span></a>
                      <a class="atlas-mega-link" href="${pagePath('articles')}"><strong>${escapeHtml(t('nav.articles'))}</strong><span>${icon('layers')} Άρθρα, ανάλυση και editorial context</span></a>
                      <a class="atlas-mega-link" href="${pagePath('sources')}"><strong>${escapeHtml(t('nav.sources'))}</strong><span>${icon('external')} Πηγές, αναφορές και τεκμηρίωση</span></a>
                    </div>
                  </div>
                </div>
              </div>
              ${navLink('elements', t('nav.elements'))}
              ${navLink('applications', t('nav.applications'))}
              ${navLink('gallery', t('nav.gallery'))}
              ${navLink('articles', t('nav.articles'))}
              ${navLink('sources', t('nav.sources'))}
            </div>
            <div class="d-flex flex-column flex-lg-row gap-2 ms-lg-3 mt-3 mt-lg-0">
              <button class="atlas-pill" data-action="lang-toggle">${icon('language')} ${state.lang.toUpperCase()}</button>
              <button class="atlas-pill" data-action="theme-toggle">${state.theme === 'dark' ? icon('sun') : icon('moon')} ${escapeHtml(themeLabel(state.theme))}</button>
            </div>
          </div>
        </div>
      </nav>
      ${buildMegaMenu()}
    </header>
    <main id="page-root"></main>
    <footer class="container-tight footer-shell">
      <div class="glass rounded-5 p-4 p-lg-5 footer-card">
        <div class="row g-4 align-items-center">
          <div class="col-lg-8">
            <div class="section-kicker mb-3">${icon('archive')} ${escapeHtml(t('footer.kicker'))}</div>
            <h2 class="h4 mb-2">${escapeHtml(t('site.title'))}</h2>
            <p class="mb-0">${escapeHtml(t('footer.copy'))}</p>
          </div>
          <div class="col-lg-4 text-lg-end">
            <span class="badge-soft">${icon('database')} ${escapeHtml(t('footer.meta'))}</span>
          </div>
        </div>
      </div>
    </footer>

    <button class="scroll-top-btn" id="scrollTopBtn" type="button" aria-label="${escapeHtml(t('cards.scrollTop'))}">${icon('top')}</button>

    <div class="modal fade" id="detailModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
          <div class="modal-header">
            <div>
              <div class="badge-soft mb-2" id="detailBadge"></div>
              <h2 class="h4 mb-0" id="detailTitle"></h2>
            </div>
            <button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="modal" aria-label="${escapeHtml(t('cards.closeLabel'))}"></button>
          </div>
          <div class="modal-body" id="detailBody"></div>
          <div class="modal-footer">
            <button type="button" class="btn btn-atlas-ghost" data-bs-dismiss="modal">${escapeHtml(t('common.close'))}</button>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="lightboxModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content lightbox-content">
          <div class="modal-header border-0 pb-0">
            <div>
              <div class="badge-soft mb-2" id="lightboxCounter"></div>
              <h2 class="h4 mb-0" id="lightboxTitle"></h2>
            </div>
            <button type="button" class="btn-close btn-close-white shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body pt-3">
            <div class="lightbox-stage">
              <button class="lightbox-nav lightbox-prev" type="button" id="lightboxPrev" aria-label="${escapeHtml(t('cards.prevImage'))}">${icon('arrow')}</button>
              <figure class="lightbox-figure mb-0">
                <div class="lightbox-media-frame"><img id="lightboxImage" src="" alt=""></div>
                <figcaption class="lightbox-caption mt-3">
                  <p class="mb-0 muted" id="lightboxCaption"></p>
                  <div id="lightboxCredit"></div>
                </figcaption>
              </figure>
              <button class="lightbox-nav lightbox-next" type="button" id="lightboxNext" aria-label="${escapeHtml(t('cards.nextImage'))}">${icon('arrow')}</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  bindShellActions();
  bindWindowChrome();
  setTheme(state.theme);
}

function bindShellActions() {
  document.querySelector('[data-action="lang-toggle"]')?.addEventListener('click', () => {
    const next = state.lang === 'el' ? 'en' : 'el';
    setLanguage(next);
  });

  document.querySelector('[data-action="theme-toggle"]')?.addEventListener('click', () => {
    const next = state.theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
  });

  const header = document.getElementById('siteHeader');
  const megaToggle = document.querySelector('[data-action="mega-toggle"]');
  const panel = document.getElementById('discoverPanel');

  const closeMega = () => {
    header?.classList.remove('mega-open');
    megaToggle?.setAttribute('aria-expanded', 'false');
    panel?.setAttribute('aria-hidden', 'true');
  };

  const toggleMega = () => {
    const willOpen = !header?.classList.contains('mega-open');
    header?.classList.toggle('mega-open', willOpen);
    megaToggle?.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
    panel?.setAttribute('aria-hidden', willOpen ? 'false' : 'true');
  };

  megaToggle?.addEventListener('click', (event) => {
    event.stopPropagation();
    toggleMega();
  });

  panel?.addEventListener('click', (event) => event.stopPropagation());

  if (window.__atlasOutsideClick) {
    document.removeEventListener('click', window.__atlasOutsideClick);
  }
  window.__atlasOutsideClick = () => closeMega();
  document.addEventListener('click', window.__atlasOutsideClick);

  if (window.__atlasEscapeHandler) {
    document.removeEventListener('keydown', window.__atlasEscapeHandler);
  }
  window.__atlasEscapeHandler = (event) => {
    if (event.key === 'Escape') closeMega();
  };
  document.addEventListener('keydown', window.__atlasEscapeHandler);

  const lightboxModalEl = document.getElementById('lightboxModal');
  const lightboxModal = bootstrap.Modal.getOrCreateInstance(lightboxModalEl);

  document.getElementById('lightboxPrev')?.addEventListener('click', () => moveLightbox(-1));
  document.getElementById('lightboxNext')?.addEventListener('click', () => moveLightbox(1));

  if (window.__atlasLightboxKeys) {
    document.removeEventListener('keydown', window.__atlasLightboxKeys);
  }

  window.__atlasLightboxKeys = (event) => {
    const isOpen = lightboxModalEl?.classList.contains('show');
    if (!isOpen) return;
    if (event.key === 'ArrowLeft') moveLightbox(-1);
    if (event.key === 'ArrowRight') moveLightbox(1);
  };
  document.addEventListener('keydown', window.__atlasLightboxKeys);

  lightboxModalEl?.addEventListener('hidden.bs.modal', () => {
    document.body.classList.remove('has-lightbox-open');
  });
  lightboxModalEl?.addEventListener('shown.bs.modal', () => {
    document.body.classList.add('has-lightbox-open');
  });

  window.__atlasLightboxModal = lightboxModal;
}

function bindWindowChrome() {
  const header = document.getElementById('siteHeader');
  const scrollTopBtn = document.getElementById('scrollTopBtn');

  const onScroll = () => {
    const y = window.scrollY || document.documentElement.scrollTop || 0;
    header?.classList.toggle('is-scrolled', y > 24);
    scrollTopBtn?.classList.toggle('is-visible', y > 420);
    if (y > 40) {
      header?.classList.remove('mega-open');
      document.querySelector('[data-action="mega-toggle"]')?.setAttribute('aria-expanded', 'false');
      document.getElementById('discoverPanel')?.setAttribute('aria-hidden', 'true');
    }
  };

  if (window.__atlasChromeHandler) {
    window.removeEventListener('scroll', window.__atlasChromeHandler);
  }

  window.__atlasChromeHandler = onScroll;
  window.addEventListener('scroll', onScroll, { passive: true });

  scrollTopBtn?.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  onScroll();
}

function issueStrip() {
  return `
    <div class="issue-strip reveal glass">
      <span>${icon('spark')} ${escapeHtml(t('cards.issueLabel'))}</span>
      <span>${icon('camera')} ${escapeHtml(t('cards.issueMedia'))}: ${state.data.media.length}</span>
      <span>${icon('archive')} ${escapeHtml(t('cards.issueThemes'))}</span>
    </div>
  `;
}

function buildMediaFrame(mediaRef, { label = '', compact = false } = {}) {
  const { media, localized } = localizedMedia(mediaRef);
  if (!media) return '';
  return `
    <figure class="media-frame ${compact ? 'compact' : ''} glass reveal">
      <div class="media-frame-image ${media.kind === 'illustration' ? 'is-illustration' : ''}" ${mediaStyle(media, compact ? 'card' : 'hero')}>
        ${(() => { const attrs = mediaImageAttrs(media); return `<img class="${attrs.className}"${attrs.styleAttr} src="${mediaUrl(media)}" alt="${escapeHtml(localized.alt || localized.title)}">`; })()}
      </div>
      <figcaption>
        ${label ? `<div class="section-kicker mb-2">${label}</div>` : ''}
        <h3>${escapeHtml(localized.title)}</h3>
        <p>${escapeHtml(localized.caption)}</p>
        ${mediaCredit(media)}
      </figcaption>
    </figure>
  `;
}

function buildElementCard(element) {
  const localized = getLocalized(element, state.lang);
  const uses = localized.uses.slice(0, 2).map((item) => `<li>${escapeHtml(item)}</li>`).join('');
  return `
    <article class="content-card glass reveal h-100 d-flex flex-column" data-open="element" data-id="${element.id}">
      <div class="card-media card-media-element">
        <img src="./assets/img/elements/${element.id}.svg" alt="${escapeHtml(localized.name)}">
      </div>
      <div class="p-4 d-flex flex-column h-100">
        <div class="d-flex justify-content-between gap-2 align-items-start mb-3">
          <div>
            <div class="badge-soft mb-2">${escapeHtml(element.symbol)} · #${element.atomicNumber}</div>
            <h3 class="h5 mb-1">${escapeHtml(localized.name)}</h3>
          </div>
          <span class="badge-soft">${escapeHtml(localized.tagline)}</span>
        </div>
        <p class="muted">${escapeHtml(localized.summary)}</p>
        <div class="mt-auto">
          <div class="small text-uppercase text-body-secondary fw-semibold mb-2">${escapeHtml(t('cards.keyUses'))}</div>
          <ul class="small muted ps-3 mb-0">${uses}</ul>
        </div>
      </div>
    </article>
  `;
}

function buildApplicationCard(app) {
  const localized = getLocalized(app, state.lang);
  const media = resolveMedia(app.mediaRef);
  return `
    <article class="content-card glass reveal h-100 d-flex flex-column" data-open="application" data-id="${app.id}">
      <div class="card-media ${media?.kind === 'illustration' ? 'card-media-illustration' : ''}" ${mediaStyle(media, 'card')}>
        ${(() => { const attrs = mediaImageAttrs(media); return `<img class="${attrs.className}"${attrs.styleAttr} src="${entityImage(app, `./assets/img/applications/${app.id}.svg`)}" alt="${escapeHtml(localized.name)}">`; })()}
      </div>
      <div class="p-4 d-flex flex-column h-100">
        <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
          <span class="badge-soft">${escapeHtml(app.sector)}</span>
          <span class="badge-soft">${escapeHtml(t('cards.archiveLabel'))}</span>
        </div>
        <h3 class="h5 mb-2">${escapeHtml(localized.name)}</h3>
        <p class="muted mb-3">${escapeHtml(localized.summary)}</p>
        <div class="tag-list mb-3">
          ${app.keyElements.map((el) => `<span class="badge-soft">${escapeHtml(el)}</span>`).join('')}
        </div>
        <div class="mt-auto">${mediaCredit(media)}</div>
      </div>
    </article>
  `;
}

function buildArticleCard(article, variant = 'default') {
  const localized = getLocalized(article, state.lang);
  const cover = resolveMedia(article.coverMediaRef);
  return `
    <article class="article-card glass reveal ${variant === 'featured' ? 'featured-article' : ''} h-100 d-flex flex-column">
      <a href="./article.html?id=${article.id}" class="card-media ${cover?.kind === 'illustration' ? 'card-media-illustration' : ''}" ${mediaStyle(cover, 'card')}>
        ${(() => { const attrs = mediaImageAttrs(cover); return `<img class="${attrs.className}"${attrs.styleAttr} src="${entityImage(article, './assets/img/gallery/atlas-overview.svg')}" alt="${escapeHtml(localized.title)}">`; })()}
      </a>
      <div class="p-4 d-flex flex-column h-100">
        <div class="d-flex justify-content-between align-items-center gap-3 mb-3 flex-wrap">
          <span class="badge-soft">${escapeHtml(article.category)}</span>
          <span class="muted small">${article.readingTime} min</span>
        </div>
        <h3 class="${variant === 'featured' ? 'h3' : 'h5'} mb-2">${escapeHtml(localized.title)}</h3>
        <p class="muted">${escapeHtml(localized.excerpt)}</p>
        <div class="mt-auto">${cardButton(t('cards.openArticle'), `./article.html?id=${article.id}`)}</div>
      </div>
    </article>
  `;
}


function buildGalleryCard(item) {
  const media = resolveMedia(item.mediaRef);
  const localized = getLocalized(media, state.lang);
  const attrs = mediaImageAttrs(media, { containForIllustration: true });
  return `
    <article class="media-card glass reveal ${item.layout || ''} ${media?.kind === 'illustration' ? 'is-illustration' : ''}">
      <div class="card-media">
        <img class="${attrs.className}"${attrs.styleAttr} src="${mediaUrl(media)}" alt="${escapeHtml(localized.alt || localized.title)}">
        ${mediaLightboxButton(media.id, t('cards.viewImage'))}
      </div>
      <div class="p-4 d-flex flex-column h-100">
        <div class="d-flex justify-content-between gap-2 align-items-center flex-wrap mb-3">
          <div class="badge-soft">${escapeHtml(item.category)}</div>
          <div class="badge-soft">${escapeHtml(media.kind)}</div>
        </div>
        <h3 class="h5 mb-2">${escapeHtml(localized.title)}</h3>
        <p class="muted mb-0">${escapeHtml(localized.caption)}</p>
        ${mediaCredit(media)}
      </div>
    </article>
  `;
}

function buildMatterCard(item) {
  return `
    <article class="matter-card glass p-4 reveal h-100">
      <div class="icon-bullet mb-3">${icon('bolt')}</div>
      <h3 class="h5 mb-2">${escapeHtml(item.title)}</h3>
      <p class="muted mb-0">${escapeHtml(item.text)}</p>
    </article>
  `;
}

function buildHero() {
  const statsHtml = state.data.config.stats.map((stat) => `
    <div class="metric-card glass">
      <strong>${escapeHtml(stat.value)}</strong>
      <span>${escapeHtml(stat.label[state.lang] || stat.label.el)}</span>
    </div>
  `).join('');

  const heroFrames = (state.data.config.heroMedia || []).slice(0, 4).map((id, index) => {
    const { media, localized } = localizedMedia(id);
    if (!media) return '';
    return `
      <article class="hero-frame glass reveal frame-${index + 1} ${media.kind === 'illustration' ? 'is-illustration' : ''}" ${mediaStyle(media, 'hero')}>
        ${(() => { const attrs = mediaImageAttrs(media); return `<img class="${attrs.className}"${attrs.styleAttr} src="${mediaUrl(media)}" alt="${escapeHtml(localized.alt || localized.title)}">`; })()}
        <div class="hero-frame-caption">
          <div class="section-kicker mb-1">${escapeHtml(media.category)}</div>
          <strong>${escapeHtml(localized.title)}</strong>
        </div>
      </article>
    `;
  }).join('');

  return `
    <section class="hero-shell container-tight">
      ${issueStrip()}
      <div class="hero-card glass">
        <div class="hero-grid">
          <div class="hero-copy reveal">
            <span class="eyebrow">${escapeHtml(t('hero.eyebrow'))}</span>
            <h1 class="display-atlas mt-3">${escapeHtml(t('hero.title'))}</h1>
            <p class="lead-atlas mt-3 mb-4">${escapeHtml(t('hero.lead'))}</p>
            <div class="d-flex flex-wrap gap-3">
              <a href="${pagePath('elements')}" class="btn btn-atlas-primary">${escapeHtml(t('hero.ctaPrimary'))}</a>
              <a href="${pagePath('articles')}" class="btn btn-atlas-ghost">${escapeHtml(t('hero.ctaSecondary'))}</a>
            </div>
            <div class="metrics-grid">${statsHtml}</div>
          </div>
          <div class="hero-collage reveal">
            ${heroFrames}
          </div>
        </div>
      </div>
    </section>
  `;
}

function buildPageHero(title, lead, mediaRef = null) {
  const figure = mediaRef ? buildMediaFrame(mediaRef, { compact: true, label: escapeHtml(t('cards.archiveLabel')) }) : '';
  return `
    <section class="page-hero section-space">
      <div class="container-tight">
        <div class="page-hero-card glass reveal ${mediaRef ? 'with-media' : ''}">
          <div>
            <span class="eyebrow">${escapeHtml(t('site.title'))}</span>
            <h1 class="display-atlas mt-3 mb-3">${escapeHtml(title)}</h1>
            <p class="lead-atlas mb-0">${escapeHtml(lead)}</p>
          </div>
          ${figure}
        </div>
      </div>
    </section>
  `;
}

function wireFilter({ items, searchTerm, selectTerm }) {
  const normalizedSearch = (searchTerm || '').trim().toLowerCase();
  return items.filter((item) => {
    const localized = getLocalized(item, state.lang);
    const haystack = [
      localized?.name,
      localized?.summary,
      item.symbol,
      ...(localized?.uses || []),
      ...(item.keyElements || []),
      ...(item.tags || []),
      item.category,
      item.sector
    ].filter(Boolean).join(' ').toLowerCase();

    const searchMatch = !normalizedSearch || haystack.includes(normalizedSearch);
    const categoryMatch = !selectTerm || selectTerm === 'all' || item.category === selectTerm || item.sector === selectTerm;
    return searchMatch && categoryMatch;
  });
}

function renderHome() {
  const { config, elements, applications, articles, gallery } = state.data;
  const featuredElements = config.featuredElements.map((id) => getEntityById(elements, id)).filter(Boolean);
  const featuredApps = config.featuredApplications.map((id) => getEntityById(applications, id)).filter(Boolean);
  const featuredArticles = config.featuredArticles.map((id) => getEntityById(articles, id)).filter(Boolean);
  const featuredGallery = config.featuredGallery.map((id) => getEntityById(gallery, id)).filter(Boolean);
  const editorPick = getEntityById(articles, config.editorPickArticle) || featuredArticles[0];

  const matterCards = t('home.matterCards', { returnObjects: true });
  const timeline = t('home.timeline', { returnObjects: true });
  const architecturePoints = t('home.architecturePoints', { returnObjects: true });
  const fieldGuideIntro = t('home.fieldGuideIntro');
  const fieldGuideOutro = t('home.fieldGuideOutro');
  const mediaLedgerItems = (config.featuredMedia || []).map((id) => getMediaById(id)).filter(Boolean);

  document.getElementById('page-root').innerHTML = `
    ${buildHero()}

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          eyebrow: `${icon('quote')} ${t('sections.editorialDeskKicker')}`,
          title: t('sections.editorialDesk'),
          lead: t('sections.editorialDeskLead')
        })}
        <div class="editorial-grid">
          <div class="editorial-main">
            ${editorPick ? buildArticleCard(editorPick, 'featured') : ''}
          </div>
          <div class="editorial-side">
            ${mediaLedgerItems.slice(0, 3).map((media, index) => buildMediaFrame(media.id, { compact: true, label: index === 0 ? escapeHtml(t('cards.editorPickLabel')) : '' })).join('')}
          </div>
        </div>
      </div>
    </section>

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          eyebrow: `${icon('spark')} ${t('sections.whyThisMatters')}`,
          title: t('sections.whyThisMatters'),
          lead: t('sections.whyThisMattersLead')
        })}
        <div class="row g-4">
          ${matterCards.map((item) => `<div class="col-md-4">${buildMatterCard(item)}</div>`).join('')}
        </div>
      </div>
    </section>

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          eyebrow: `${icon('camera')} ${t('sections.mediaLedgerKicker')}`,
          title: t('sections.mediaLedger'),
          lead: t('sections.mediaLedgerLead')
        })}
        <div class="row g-4 align-items-stretch">
          ${mediaLedgerItems.map((media, idx) => `<div class="col-md-6 ${idx === 0 ? 'col-xl-6' : 'col-xl-3'}">${buildMediaFrame(media.id, { compact: idx !== 0, label: escapeHtml(t('cards.archiveLabel')) })}</div>`).join('')}
        </div>
      </div>
    </section>

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          title: t('sections.featuredElements'),
          actionHtml: cardButton(t('cards.viewAll'), pagePath('elements'))
        })}
        <div class="row g-4">
          ${featuredElements.map((item) => `<div class="col-md-6 col-xl-3">${buildElementCard(item)}</div>`).join('')}
        </div>
      </div>
    </section>

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          title: t('sections.featuredApplications'),
          actionHtml: cardButton(t('cards.viewAll'), pagePath('applications'))
        })}
        <div class="row g-4">
          ${featuredApps.map((item) => `<div class="col-md-6 col-xl-3">${buildApplicationCard(item)}</div>`).join('')}
        </div>
      </div>
    </section>

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          title: t('sections.curatedArchive'),
          lead: t('sections.curatedArchiveLead'),
          actionHtml: cardButton(t('cards.viewAll'), pagePath('gallery'))
        })}
        <div class="row g-4">
          ${featuredGallery.map((item) => `<div class="col-md-6 col-xl-3">${buildGalleryCard(item)}</div>`).join('')}
        </div>
      </div>
    </section>

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          title: t('sections.featuredArticles'),
          actionHtml: cardButton(t('cards.viewAll'), pagePath('articles'))
        })}
        <div class="row g-4">
          ${featuredArticles.map((item, index) => `<div class="${index === 0 ? 'col-lg-6' : 'col-md-6 col-xl-3'}">${buildArticleCard(item, index === 0 ? 'featured' : 'default')}</div>`).join('')}
        </div>
      </div>
    </section>

    <section class="section-space pt-0">
      <div class="container-tight">
        ${createSectionTitle({
          title: t('sections.timeline'),
          lead: t('sections.architectureLead')
        })}
        <div class="row g-4 align-items-stretch">
          <div class="col-lg-5">
            <div class="glass p-4 h-100 rounded-5 reveal">
              <div class="timeline-shell">
                ${timeline.map((item, idx) => `
                  <div class="timeline-step">
                    <div class="timeline-index">${idx + 1}</div>
                    <div class="pt-1">${escapeHtml(item)}</div>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
          <div class="col-lg-7">
            <div class="glass p-4 p-lg-5 rounded-5 reveal architecture-shell">
              <div class="badge-soft mb-3">${icon('layers')} ${escapeHtml(t('sections.architecture'))}</div>
              <h3 class="h4 mb-3">${escapeHtml(t('sections.architecture'))}</h3>
              <p class="muted mb-4">${escapeHtml(fieldGuideIntro)}</p>
              <ul class="list-clean mb-4">
                ${architecturePoints.map((item) => `<li><span class="icon-bullet">${icon('layers')}</span><span>${escapeHtml(item)}</span></li>`).join('')}
              </ul>
              <p class="mb-0 muted">${escapeHtml(fieldGuideOutro)}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  `;

  bindGalleryLightbox(featuredGallery);
}

function renderElements() {
  const title = t('page.elementsTitle');
  const lead = t('page.elementsLead');
  document.getElementById('page-root').innerHTML = `
    ${buildPageHero(title, lead, 'editorial-atlas-overview')}
    <section class="section-space pt-0">
      <div class="container-tight">
        <div class="filter-bar reveal">
          <div class="input-shell px-3 py-2">
            <input id="elementSearch" class="form-control" placeholder="${escapeHtml(t('filters.searchPlaceholder'))}" />
          </div>
          <div class="select-shell px-2 py-2">
            <select id="elementCategory" class="form-select">
              <option value="all">${escapeHtml(t('filters.categoryAll'))}</option>
              <option value="magnet">magnet</option>
              <option value="display">display</option>
              <option value="medical">medical</option>
              <option value="catalyst">catalyst</option>
              <option value="laser">laser</option>
              <option value="alloy">alloy</option>
              <option value="niche">niche</option>
            </select>
          </div>
        </div>
        <div id="elementsGrid" class="row g-4"></div>
      </div>
    </section>
  `;

  const grid = document.getElementById('elementsGrid');
  const rerender = () => {
    const filtered = wireFilter({
      items: state.data.elements,
      searchTerm: document.getElementById('elementSearch').value,
      selectTerm: document.getElementById('elementCategory').value
    });

    grid.innerHTML = filtered.length
      ? filtered.map((item) => `<div class="col-md-6 col-xl-4">${buildElementCard(item)}</div>`).join('')
      : `<div class="col-12"><div class="empty-state glass">${escapeHtml(t('common.noMatchingElements'))}</div></div>`;

    bindDetailTriggers();
    revealAll(grid);
  };

  document.getElementById('elementSearch').addEventListener('input', rerender);
  document.getElementById('elementCategory').addEventListener('change', rerender);
  rerender();
}

function renderApplications() {
  const title = t('page.applicationsTitle');
  const lead = t('page.applicationsLead');
  document.getElementById('page-root').innerHTML = `
    ${buildPageHero(title, lead, 'editorial-supply-chain')}
    <section class="section-space pt-0">
      <div class="container-tight">
        <div class="filter-bar reveal">
          <div class="input-shell px-3 py-2">
            <input id="applicationSearch" class="form-control" placeholder="${escapeHtml(t('filters.searchPlaceholder'))}" />
          </div>
          <div class="select-shell px-2 py-2">
            <select id="applicationSector" class="form-select">
              <option value="all">${escapeHtml(t('filters.sectorAll'))}</option>
              <option value="consumer-tech">consumer-tech</option>
              <option value="mobility">mobility</option>
              <option value="energy">energy</option>
              <option value="medical">medical</option>
              <option value="industry">industry</option>
              <option value="science-defense">science-defense</option>
            </select>
          </div>
        </div>
        <div id="applicationsGrid" class="row g-4"></div>
      </div>
    </section>
  `;

  const grid = document.getElementById('applicationsGrid');
  const rerender = () => {
    const filtered = wireFilter({
      items: state.data.applications,
      searchTerm: document.getElementById('applicationSearch').value,
      selectTerm: document.getElementById('applicationSector').value
    });

    grid.innerHTML = filtered.length
      ? filtered.map((item) => `<div class="col-md-6 col-xl-4">${buildApplicationCard(item)}</div>`).join('')
      : `<div class="col-12"><div class="empty-state glass">${escapeHtml(t('common.noMatchingApplications'))}</div></div>`;

    bindDetailTriggers();
    revealAll(grid);
  };

  document.getElementById('applicationSearch').addEventListener('input', rerender);
  document.getElementById('applicationSector').addEventListener('change', rerender);
  rerender();
}

function renderGallery() {
  const title = t('page.galleryTitle');
  const lead = t('page.galleryLead');

  document.getElementById('page-root').innerHTML = `
    ${buildPageHero(title, lead, 'editorial-recycling')}
    <section class="section-space pt-0">
      <div class="container-tight">
        <div class="filter-bar reveal">
          <div class="input-shell px-3 py-2">
            <input id="gallerySearch" class="form-control" placeholder="${escapeHtml(t('filters.searchPlaceholder'))}" />
          </div>
          <div class="select-shell px-2 py-2">
            <select id="galleryCategory" class="form-select">
              <option value="all">${escapeHtml(t('filters.galleryAll'))}</option>
              <option value="material">material</option>
              <option value="application">application</option>
              <option value="industry">industry</option>
              <option value="editorial">editorial</option>
            </select>
          </div>
        </div>
        <div id="galleryGrid" class="gallery-grid"></div>
      </div>
    </section>
  `;

  const grid = document.getElementById('galleryGrid');
  const rerender = () => {
    const search = document.getElementById('gallerySearch').value.trim().toLowerCase();
    const category = document.getElementById('galleryCategory').value;

    const filtered = state.data.gallery.filter((item) => {
      const media = resolveMedia(item.mediaRef);
      const localized = getLocalized(media, state.lang);
      const haystack = `${localized.title} ${localized.caption} ${item.category} ${(media.tags || []).join(' ')}`.toLowerCase();
      const searchMatch = !search || haystack.includes(search);
      const categoryMatch = category === 'all' || item.category === category;
      return searchMatch && categoryMatch;
    });

    grid.innerHTML = filtered.length
      ? filtered.map((item) => buildGalleryCard(item)).join('')
      : `<div class="empty-state glass">${escapeHtml(t('common.noMatchingVisuals'))}</div>`;

    bindGalleryLightbox(filtered);
    revealAll(grid);
  };

  document.getElementById('gallerySearch').addEventListener('input', rerender);
  document.getElementById('galleryCategory').addEventListener('change', rerender);
  rerender();
}

function renderArticles() {
  const title = t('page.articlesTitle');
  const lead = t('page.articlesLead');
  const [leadArticle, ...rest] = state.data.articles;

  document.getElementById('page-root').innerHTML = `
    ${buildPageHero(title, lead, leadArticle?.coverMediaRef || 'editorial-atlas-overview')}
    <section class="section-space pt-0">
      <div class="container-tight article-index-grid">
        <div class="article-index-lead">
          ${leadArticle ? buildArticleCard(leadArticle, 'featured') : ''}
        </div>
        <div class="row g-4 article-index-list">
          ${rest.map((item) => `<div class="col-md-6">${buildArticleCard(item)}</div>`).join('')}
        </div>
      </div>
    </section>
  `;
}

function renderSources() {
  const title = t('page.sourcesTitle');
  const lead = t('page.sourcesLead');

  document.getElementById('page-root').innerHTML = `
    ${buildPageHero(title, lead, 'editorial-supply-chain')}
    <section class="section-space pt-0">
      <div class="container-tight">
        <div class="row g-4">
          ${state.data.sources.map((source) => `<div class="col-md-6 col-xl-4">${buildSourceLink(source, t)}</div>`).join('')}
        </div>
      </div>
    </section>
  `;
}

function renderArticle() {
  const params = new URLSearchParams(window.location.search);
  const article = getEntityById(state.data.articles, params.get('id'));

  if (!article) {
    document.getElementById('page-root').innerHTML = `
      ${buildPageHero(t('page.notFound'), '', 'editorial-atlas-overview')}
      <section class="section-space pt-0">
        <div class="container-tight">
          <a href="${pagePath('articles')}" class="btn btn-atlas-primary">${escapeHtml(t('page.articleBack'))}</a>
        </div>
      </section>
    `;
    return;
  }

  const localized = getLocalized(article, state.lang);
  const sourceList = article.sourceRefs.map((id) => getEntityById(state.data.sources, id)).filter(Boolean);
  const cover = resolveMedia(article.coverMediaRef);

  document.getElementById('page-root').innerHTML = `
    <section class="page-hero section-space">
      <div class="container-tight">
        <a href="${pagePath('articles')}" class="atlas-pill mb-4 d-inline-flex align-items-center gap-2">${icon('arrow')} ${escapeHtml(t('page.articleBack'))}</a>
        <div class="article-cover glass reveal ${cover?.kind === 'illustration' ? 'is-illustration' : ''}" ${mediaStyle(cover, 'cover')}>
          ${(() => { const attrs = mediaImageAttrs(cover); return `<img class="${attrs.className}"${attrs.styleAttr} src="${entityImage(article, './assets/img/gallery/atlas-overview.svg')}" alt="${escapeHtml(localized.title)}">`; })()}
        </div>
        <div class="article-layout">
          <article>
            <div class="page-hero-card glass reveal mb-4 article-header-card">
              <div class="d-flex flex-wrap gap-2 mb-3">
                <span class="badge-soft">${escapeHtml(article.category)}</span>
                <span class="badge-soft">${article.readingTime} min</span>
                <span class="badge-soft">${escapeHtml(t('cards.archiveLabel'))}</span>
              </div>
              <div class="section-kicker mb-3">${icon('quote')} ${escapeHtml(t('cards.articleDeck'))}</div>
              <h1 class="display-atlas mb-3">${escapeHtml(localized.title)}</h1>
              <p class="lead-atlas mb-0 article-intro">${escapeHtml(localized.intro)}</p>
            </div>
            <div class="article-prose article-prose-editorial">
              ${localized.sections.map((section, index) => `
                <section class="article-section glass reveal">
                  <div class="section-kicker mb-2">${escapeHtml(t('cards.sectionLabel'))} ${index + 1}</div>
                  <h3>${escapeHtml(section.heading)}</h3>
                  <div class="article-copy">
                    <p class="mb-0">${escapeHtml(section.body)}</p>
                  </div>
                </section>
              `).join('')}
            </div>
          </article>

          <aside class="d-grid gap-3 article-aside">
            <div class="glass p-4 rounded-5 reveal">
              <div class="badge-soft mb-3">${icon('camera')} ${escapeHtml(t('cards.relatedMedia'))}</div>
              <div class="d-grid gap-3 related-media-stack">
                ${(article.mediaRefs || []).slice(0, 4).map((mediaId) => buildMediaFrame(mediaId, { compact: true })).join('')}
              </div>
            </div>
            <div class="glass p-4 rounded-5 reveal">
              <div class="badge-soft mb-3">${icon('layers')} ${escapeHtml(t('cards.references'))}</div>
              <div class="d-grid gap-3">
                ${sourceList.map((source) => `
                  <a href="${source.url}" target="_blank" rel="noreferrer" class="source-card glass p-3 d-block">
                    <div class="small text-uppercase text-body-secondary mb-2">${escapeHtml(source.publisher)}</div>
                    <strong>${escapeHtml(source.title)}</strong>
                  </a>
                `).join('')}
              </div>
            </div>
            <div class="glass p-4 rounded-5 reveal">
              <div class="badge-soft mb-3">${icon('quote')} ${escapeHtml(t('cards.articleContext'))}</div>
              <p class="mb-0 muted">${escapeHtml(localized.excerpt || t('common.apiReadyNote'))}</p>
            </div>
          </aside>
        </div>
      </div>
    </section>
  `;
}

function firstLinkedMedia(type, id) {
  return (state.data.media || []).find((media) => (media.linkedTo?.[type] || []).includes(id));
}

function bindDetailTriggers() {
  const modalEl = document.getElementById('detailModal');
  const modal = bootstrap.Modal.getOrCreateInstance(modalEl);

  document.querySelectorAll('[data-open="element"]').forEach((node) => {
    node.addEventListener('click', () => {
      const item = getEntityById(state.data.elements, node.dataset.id);
      const localized = getLocalized(item, state.lang);
      const media = firstLinkedMedia('elements', item.id);
      document.getElementById('detailBadge').innerHTML = `${escapeHtml(item.symbol)} · #${item.atomicNumber}`;
      document.getElementById('detailTitle').textContent = localized.name;
      document.getElementById('detailBody').innerHTML = `
        <div class="row g-4 align-items-start">
          <div class="col-md-5">
            ${media ? `<div class="modal-media-frame ${media.kind === 'illustration' ? 'is-illustration' : ''}">${(() => { const attrs = mediaImageAttrs(media); return `<img class="rounded-4 ${attrs.className}"${attrs.styleAttr} src="${mediaUrl(media)}" alt="${escapeHtml(getLocalized(media, state.lang).alt || getLocalized(media, state.lang).title)}">`; })()}</div>` : `<img class="rounded-4" src="./assets/img/elements/${item.id}.svg" alt="${escapeHtml(localized.name)}">`}
            ${media ? mediaCredit(media) : ''}
          </div>
          <div class="col-md-7">
            <p class="muted">${escapeHtml(localized.summary)}</p>
            <div class="badge-soft mb-3">${escapeHtml(localized.tagline)}</div>
            <h3 class="h6">${escapeHtml(t('cards.keyUses'))}</h3>
            <ul class="ps-3">
              ${localized.uses.map((use) => `<li>${escapeHtml(use)}</li>`).join('')}
            </ul>
            <div class="glass rounded-4 p-3 mt-3">
              <strong>${escapeHtml(localized.fact)}</strong>
            </div>
          </div>
        </div>
      `;
      modal.show();
    });
  });

  document.querySelectorAll('[data-open="application"]').forEach((node) => {
    node.addEventListener('click', () => {
      const item = getEntityById(state.data.applications, node.dataset.id);
      const localized = getLocalized(item, state.lang);
      const media = resolveMedia(item.mediaRef);
      document.getElementById('detailBadge').innerHTML = `${escapeHtml(item.sector)} · ${item.keyElements.join(' · ')}`;
      document.getElementById('detailTitle').textContent = localized.name;
      document.getElementById('detailBody').innerHTML = `
        <div class="row g-4 align-items-start">
          <div class="col-md-5">
            <div class="modal-media-frame ${media?.kind === 'illustration' ? 'is-illustration' : ''}">
              ${(() => { const attrs = mediaImageAttrs(media); return `<img class="rounded-4 ${attrs.className}"${attrs.styleAttr} src="${entityImage(item, `./assets/img/applications/${item.id}.svg`)}" alt="${escapeHtml(localized.name)}">`; })()}
            </div>
            ${mediaCredit(media)}
          </div>
          <div class="col-md-7">
            <p class="muted">${escapeHtml(localized.summary)}</p>
            <h3 class="h6">${escapeHtml(t('cards.whatItDoes'))}</h3>
            <p>${escapeHtml(localized.whatItDoes)}</p>
            <h3 class="h6">${escapeHtml(t('cards.howItWorks'))}</h3>
            <p class="mb-3">${escapeHtml(localized.howItWorks)}</p>
            <div class="tag-list">
              ${item.keyElements.map((el) => `<span class="badge-soft">${escapeHtml(el)}</span>`).join('')}
            </div>
          </div>
        </div>
      `;
      modal.show();
    });
  });
}


function moveLightbox(step) {
  updateLightbox(state.lightboxIndex + step);
}

function updateLightbox(index) {
  const modalEl = document.getElementById('lightboxModal');
  const image = document.getElementById('lightboxImage');
  if (!modalEl || !image || !state.galleryItems.length) return;
  const total = state.galleryItems.length;
  state.lightboxIndex = (index + total) % total;
  const item = state.galleryItems[state.lightboxIndex];
  const media = item.media || resolveMedia(item.mediaRef);
  const localized = getLocalized(media, state.lang);
  const attrs = mediaImageAttrs(media, { containForIllustration: true });
  image.className = attrs.className;
  image.setAttribute('style', media?.objectPosition ? `object-position:${media.objectPosition}` : '');
  image.src = mediaUrl(media);
  image.alt = localized.alt || localized.title || '';
  document.getElementById('lightboxTitle').textContent = localized.title || '';
  document.getElementById('lightboxCaption').textContent = localized.caption || '';
  document.getElementById('lightboxCounter').textContent = t('cards.imageCounter', { current: state.lightboxIndex + 1, total });
  document.getElementById('lightboxCredit').innerHTML = mediaCredit(media);
}

function openLightbox(mediaId) {
  const modalEl = document.getElementById('lightboxModal');
  const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
  const idx = state.galleryItems.findIndex((item) => item.mediaRef === mediaId || item.media?.id === mediaId);
  updateLightbox(idx >= 0 ? idx : 0);
  modal.show();
}

function bindGalleryLightbox(items = []) {
  state.galleryItems = (items || []).map((item) => {
    const media = item?.media || resolveMedia(item?.mediaRef || item?.coverMediaRef || item?.id || item);
    return {
      ...item,
      media,
      mediaRef: item?.mediaRef || media?.id || null
    };
  }).filter((item) => item.media);

  bindLightboxTriggers();

  if (!state.galleryItems.length) {
    const modalEl = document.getElementById('lightboxModal');
    const modal = modalEl ? bootstrap.Modal.getOrCreateInstance(modalEl) : null;
    modal?.hide();
  }
}

function bindLightboxTriggers() {
  document.querySelectorAll('[data-open="lightbox"]').forEach((node) => {
    node.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      openLightbox(node.dataset.mediaId);
    });
  });

  document.getElementById('lightboxPrev')?.addEventListener('click', () => updateLightbox(state.lightboxIndex - 1));
  document.getElementById('lightboxNext')?.addEventListener('click', () => updateLightbox(state.lightboxIndex + 1));

  if (window.__atlasLightboxKeyHandler) {
    document.removeEventListener('keydown', window.__atlasLightboxKeyHandler);
  }
  window.__atlasLightboxKeyHandler = (event) => {
    const modalEl = document.getElementById('lightboxModal');
    if (!modalEl?.classList.contains('show')) return;
    if (event.key === 'ArrowLeft') updateLightbox(state.lightboxIndex - 1);
    if (event.key === 'ArrowRight') updateLightbox(state.lightboxIndex + 1);
  };
  document.addEventListener('keydown', window.__atlasLightboxKeyHandler);
}

function renderPage() {
  switch (currentPage()) {
    case 'elements':
      return renderElements();
    case 'applications':
      return renderApplications();
    case 'gallery':
      return renderGallery();
    case 'articles':
      return renderArticles();
    case 'article':
      return renderArticle();
    case 'sources':
      return renderSources();
    default:
      return renderHome();
  }
}

function render() {
  renderShell();
  renderPage();
  bindDetailTriggers();
  bindLightboxTriggers();
  revealAll(document);
  document.documentElement.lang = state.lang;
}

async function init() {
  state.data = await loadAppData();

  const resources = await loadTranslations();
  await window.i18next.init({
    lng: state.lang,
    fallbackLng: 'el',
    resources
  });

  render();
}

init().catch((error) => {
  console.error(error);
  document.getElementById('app').innerHTML = `
    <main class="container-tight py-5">
      <div class="glass p-5 rounded-5">
        <h1 class="h3 mb-3">Project boot error</h1>
        <p class="mb-0">${escapeHtml(error.message)}</p>
      </div>
    </main>
  `;
});
